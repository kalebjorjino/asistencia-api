<footer class="footer bg-light py-3">
    <div class="container-fluid text-center text-muted">
        <div class="row">
            <div class="col-12">
                2023 © Garcia Vasquez Jorjino. - 20159238si@gmail.com
            </div>
        </div>
    </div>
</footer>