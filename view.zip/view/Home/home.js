function init(){
   
}

$(document).ready(function(){
    
    
});

init();