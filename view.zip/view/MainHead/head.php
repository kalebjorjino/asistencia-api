
<link rel="stylesheet" href="../../public/css/separate/vendor/blockui.min.css">

<link rel="stylesheet" href="../../public/css/separate/vendor/fancybox.min.css">
<link rel="stylesheet" href="../../public/css/separate/pages/activity.min.css">

<link rel="stylesheet" href="../../public/css/lib/summernote/summernote.css"/>
<link rel="stylesheet" href="../../public/css/separate/pages/editor.min.css">

<link rel="stylesheet" href="../../public/css/lib/font-awesome/font-awesome.min.css">
<link rel="stylesheet" href="../../public/css/lib/bootstrap/bootstrap.min.css">

<link rel="stylesheet" href="../../public/css/lib/bootstrap-sweetalert/sweetalert.css">
<link rel="stylesheet" href="../../public/css/separate/vendor/sweet-alert-animations.min.css">

<link rel="stylesheet" href="../../public/css/lib/datatables-net/datatables.min.css">
<link rel="stylesheet" href="../../public/css/separate/vendor/datatables-net.min.css">

<link rel="stylesheet" href="../../public/css/separate/vendor/select2.min.css">

<link rel="stylesheet" href="../../public/css/main.css">
